Attached are the data sets used in the manuscript.

### ACKLT_complete_fasta ###
Full data set of 9,045 sequences following filtering in Mothur.


### ACKLT_275trim.fasta ###
Data set (ACKLT_complete_fasta) with all reads trimmed to 275 bp.
Original reads under 275 bp were discarded, reducing the number of 
sequences to 8,991. This file was used in the de novo clustering of OTUs.


### OTUs folder ###
Aligned nexus files for all 31 OTUs in the comparative data set.
