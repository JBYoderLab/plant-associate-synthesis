Microsatellite data are on two separate sheets, depending on the species.
For each sheet:
- first line: marker names
- second line: column titles
- third line and ongoing: sample code, sampling location, genotypes (one allele per cell, two alleles per marker)
Alleles codes account for measured amplicon sizes; n/a account for amplification failures.
